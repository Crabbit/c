CREATE TABLE subway7(
n1 int,
n2 int,
n3 int,
n4 int,
n5 int,
n6 int,
n7 int
);


INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(1,2,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(1,3,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(1,4,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(1,5,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(1,7,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(1,8,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(1,9,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(1,10,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(2,3,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(2,4,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(2,6,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(2,7,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(2,8,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(2,9,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(2,10,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(2,11,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(3,4,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(3,7,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(3,8,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(3,9,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(3,10,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(3,11,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(4,6,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(4,7,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(4,8,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(4,9,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(4,10,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(4,11,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(6,7,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(6,9,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(7,8,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(7,9,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(8,9,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(8,10,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(9,12,1,0,0,0,0);
INSERT INTO subway7(n1,n2,n3,n4,n5,n6,n7) VALUES(11,13,1,0,0,0,0);


