CREATE TABLE subway5(
n1 int,
n2 int,
n3 int,
n4 int
);

INSERT INTO subway5(n1,n2,n3,n4) VALUES(14,36,1,13);

