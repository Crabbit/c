create table subway3 (
sub1 integer,
sub2 integer,
weight integer,
min_num integer,
max_num integer,
num1 integer,
num2 integer
);


INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(0,1,2,166,166,8,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(0,17,2,165,165,10,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(0,36,8,152,158,8,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(0,37,7,159,164,10,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(1,2,2,182,182,3,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(1,20,4,179,181,8,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(1,48,13,167,178,3,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(2,3,1,0,0,3,4);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(2,17,1,0,0,4,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(3,4,1,0,0,3,4);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(3,20,3,194,195,1,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(3,49,12,183,193,1,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(4,5,1,0,0,3,4);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(5,6,1,0,0,3,4);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(5,19,3,204,205,7,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(5,50,9,196,203,7,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(6,7,1,0,0,3,4);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(6,18,2,215,215,11,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(6,35,10,206,214,11,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(7,8,1,0,0,3,4);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(8,9,1,0,0,3,4);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(8,18,1,0,0,2,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(8,40,7,216,221,2,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(9,10,1,0,0,3,4);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(10,11,1,0,0,3,4);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(10,23,3,228,229,10,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(10,41,7,222,227,10,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(11,12,1,0,0,4,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(11,25,1,0,0,9,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(11,29,4,241,243,3,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(11,42,12,230,240,9,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(12,13,2,252,252,4,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(12,25,1,0,0,1,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(12,29,2,244,244,1,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(13,14,3,248,249,4,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(13,26,1,0,0,7,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(13,31,4,245,247,7,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(14,15,3,250,251,4,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(14,28,1,0,0,8,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(14,31,1,0,0,8,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(15,16,2,255,255,6,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(15,32,3,253,254,6,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(16,17,5,278,281,4,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(16,21,3,276,277,2,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(16,28,3,274,275,9,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(16,33,3,272,273,2,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(16,46,16,257,271,6,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(17,21,3,282,283,10,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(18,19,1,0,0,2,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(19,22,1,0,0,7,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(19,20,2,284,284,2,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(20,21,1,0,0,2,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(20,23,2,286,286,1,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(20,24,2,285,285,8,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(21,24,2,287,287,10,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(22,23,1,0,0,1,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(22,25,2,288,288,1,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(22,26,1,0,0,7,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(23,24,2,289,289,10,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(24,28,1,0,0,8,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(25,26,1,0,0,9,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(26,27,3,290,291,9,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(27,28,1,0,0,9,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(27,47,2,292,292,12,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(29,30,4,293,295,1,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(30,43,10,296,304,5,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(31,32,2,305,305,7,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(31,44,8,306,312,8,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(32,33,4,313,315,7,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(32,45,5,316,319,6,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(33,34,11,320,329,2,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(33,51,1,0,0,7,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(35,38,3,330,331,11,0);
INSERT INTO subway3(sub1,sub2,weight,min_num,max_num,num1,num2) VALUES(35,39,3,332,333,13,0);

