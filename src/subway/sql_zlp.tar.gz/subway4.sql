CREATE TABLE subway4 (
num int,
n1 int,
n2 int,
n3 int,
n4 int
);

INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(0,8,10,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(1,3,8,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(2,3,4,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(3,1,4,3,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(4,3,4,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(5,3,4,7,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(6,3,4,11,21);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(7,3,4,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(8,2,3,4,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(9,3,4,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(10,3,4,10,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(11,3,4,9,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(12,1,4,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(13,4,7,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(14,4,8,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(15,4,6,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(16,2,4,6,9);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(17,4,10,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(18,2,11,21,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(19,2,7,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(20,1,8,2,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(21,2,10,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(22,1,7,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(23,1,10,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(24,8,10,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(25,1,9,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(26,7,9,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(27,9,13,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(28,8,9,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(29,1,3,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(30,1,5,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(31,7,8,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(32,6,7,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(33,2,7,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(34,2,0,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(35,11,21,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(36,8,0,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(37,10,0,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(38,11,0,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(39,21,0,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(40,2,0,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(41,10,0,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(42,9,0,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(43,5,0,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(44,8,0,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(45,6,0,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(46,6,0,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(47,13,0,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(48,3,0,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(49,1,0,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(50,7,0,0,0);
INSERT INTO subway4(num,n1,n2,n3,n4) VALUES(51,7,0,0,0);


