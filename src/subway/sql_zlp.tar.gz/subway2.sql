create table subway2 (
n1 int,
n2 int,
n3 int,
n4 int
);

insert into subway2(n1,n2,n3,n4) values(52,74,0,51);


